import{c as s,u as n,al as u,am as a}from"./index-XYziK7Gq.js";import{u as r}from"./useMutation-D5kdJFrH.js";/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=s("ArrowDownLeft",[["path",{d:"M17 7 7 17",key:"15tmo1"}],["path",{d:"M17 17H7V7",key:"1org7z"}]]);function c(e,i={}){return n({queryKey:["lead-emails",e,i],queryFn:()=>a.getLeadEmails(e,i),enabled:!!e})}function d(e={}){return n({queryKey:["email-inbox",e],queryFn:()=>a.getInbox(e)})}function m(){const e=u();return r({mutationFn:({emailId:i,data:t})=>a.sendReply(i,t),onSuccess:()=>{e.invalidateQueries({queryKey:["email-inbox"]}),e.invalidateQueries({queryKey:["lead-emails"]}),e.invalidateQueries({queryKey:["email-thread"]})}})}function q(){const e=u();return r({mutationFn:()=>a.triggerSync(),onSuccess:()=>{e.invalidateQueries({queryKey:["email-inbox"]}),e.invalidateQueries({queryKey:["lead-emails"]})}})}export{y as A,m as a,d as b,q as c,c as u};
