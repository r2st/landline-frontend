import{c as r,u as v,z as n,q as s,a6 as i}from"./index-XYziK7Gq.js";import{u}from"./useMutation-D5kdJFrH.js";/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=r("Bold",[["path",{d:"M14 12a4 4 0 0 0 0-8H6v8",key:"v2sylx"}],["path",{d:"M15 20a4 4 0 0 0 0-8H6v8Z",key:"1ef5ya"}]]);/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=r("Italic",[["line",{x1:"19",x2:"10",y1:"4",y2:"4",key:"15jd3p"}],["line",{x1:"14",x2:"5",y1:"20",y2:"20",key:"bu0au3"}],["line",{x1:"15",x2:"9",y1:"4",y2:"20",key:"uljnxc"}]]);/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=r("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $=r("Save",[["path",{d:"M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z",key:"1owoqh"}],["polyline",{points:"17 21 17 13 7 13 7 21",key:"1md35c"}],["polyline",{points:"7 3 7 8 15 8",key:"8nz8an"}]]);function c(e,a){var o,l;return((l=(o=e==null?void 0:e.response)==null?void 0:o.data)==null?void 0:l.detail)||(e==null?void 0:e.message)||a}function G(){return v({queryKey:["gmail-status"],queryFn:async()=>await i.status(),staleTime:1e4})}function x(e){return new Promise((a,o)=>{const w=window.screenX+Math.max(0,(window.outerWidth-520)/2),h=window.screenY+Math.max(0,(window.outerHeight-640)/2),y=window.open(e,"landline-gmail-oauth",`width=520,height=640,left=${w},top=${h}`);if(!y){o(new Error("Popup blocked — allow popups for this site and try again."));return}let g=!1;const d=(m,t)=>{g||(g=!0,window.removeEventListener("message",p),clearInterval(f),m(t))},p=m=>{const t=m.data;!t||t.source!=="landline-gmail-oauth"||(t.status==="connected"?d(a,t.message||"Gmail connected"):d(o,new Error(t.message||"Connection failed")))};window.addEventListener("message",p);const f=setInterval(()=>{y.closed&&d(a,null)},600)})}function K(){return u({mutationFn:async()=>{const{authorization_url:e}=await i.authorize();return await x(e)},onSuccess:e=>{s.invalidateQueries({queryKey:["gmail-status"]}),e&&n.success(e)},onError:e=>n.error(c(e,"Could not connect Gmail"))})}function Q(){return u({mutationFn:async e=>await i.setActive(e),onSuccess:e=>{s.invalidateQueries({queryKey:["gmail-status"]}),n.success(`Now sending as ${e.email}`)},onError:e=>n.error(c(e,"Failed to set active account"))})}function z(){return u({mutationFn:async e=>await i.disconnect(e),onSuccess:()=>{s.invalidateQueries({queryKey:["gmail-status"]}),n.success("Gmail account disconnected")},onError:e=>n.error(c(e,"Failed to disconnect"))})}function I(){return u({mutationFn:async e=>await i.purge(e),onSuccess:e=>{s.invalidateQueries({queryKey:["gmail-status"]}),s.invalidateQueries({queryKey:["email-inbox"]}),n.success(`Removed ${e.email} and deleted ${e.total_deleted} emails`)},onError:e=>n.error(c(e,"Failed to purge account"))})}function b(){return u({mutationFn:async({id:e,enabled:a})=>await i.toggleSending(e,a),onSuccess:e=>{s.invalidateQueries({queryKey:["gmail-status"]}),n.success(e.sending_enabled?`${e.email} added to sending rotation`:`${e.email} removed from rotation`)},onError:e=>n.error(c(e,"Failed to toggle sending"))})}export{k as B,F as I,E as M,$ as S,K as a,Q as b,z as c,I as d,b as e,G as u};
